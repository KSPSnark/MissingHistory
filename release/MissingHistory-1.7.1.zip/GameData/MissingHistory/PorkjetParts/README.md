The models and textures in the Engine and FuelTank folders are
taken from Porkjet's PartOverhauls, and are license CC-BY-NC 3.0
by Porkjet / SQUAD.

Config files are adapted by Snark from Porkjet's originals, under
the same license.

Original zip file from Porkjet is located here:
http://kerbalspaceprogram.com/files/PartOverhauls.zip

Forum announcement thread with link to the above zip file is here:
https://forum.kerbalspaceprogram.com/index.php?/topic/147582-update-12-pre-release-is-here/


The models and textures in the Atomic Age folder and its subfolders
are taken from Porkjet's AtomicAge mod, and are license CC-BY-NC-SA 4.0
by Porkjet. You can find his original mod posted in the following locations:
Forum thread: https://forum.kerbalspaceprogram.com/index.php?/topic/94519-105-atomic-age-nuclear-propulsion-red-hot-radiators/
SpaceDock download: https://spacedock.info/mod/316/Atomic%20Age
