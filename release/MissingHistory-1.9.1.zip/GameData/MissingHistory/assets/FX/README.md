Rocket plume effects in this folder are licensed CC-BY-NC-SA 4.0
by JadeOfMaar, who kindly created them for us.
