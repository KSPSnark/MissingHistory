Orange/gray paint scheme for size 1 tanks is licensed CC-BY-NC-SA by Jarin:
https://forum.kerbalspaceprogram.com/index.php?/profile/71395-jarin/