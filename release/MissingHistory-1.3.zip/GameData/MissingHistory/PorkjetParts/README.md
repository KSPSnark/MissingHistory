The models and textures in this folder and its subfolders are
taken from Porkjet's PartOverhauls, and are license CC-BY-NC 3.0
by Porkjet / SQUAD.

Config files are adapted by Snark from Porkjet's originals, under
the same license.

Original zip file from Porkjet is located here:
http://kerbalspaceprogram.com/files/PartOverhauls.zip

Forum announcement thread with link to the above zip file is here:
https://forum.kerbalspaceprogram.com/index.php?/topic/147582-update-12-pre-release-is-here/